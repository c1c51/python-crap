x=int(input("whats your age"))
print(x)
