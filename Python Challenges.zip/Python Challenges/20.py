y=0
while y==0:
    x=int(input("number?"))
    if x==7:
        print("well done")
        y=1
    else:
        print("wrong")
