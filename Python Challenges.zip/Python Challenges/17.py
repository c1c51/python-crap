y=1
while y<=99:
    print(y)
    y=y+2
