w=int(input("width?"))
l=int(input("length?"))
print(w*l)
