mark=int(input("what mark did you get?"))
    if mark>=75:
        print("you got an A")
    elif mark>=60:
        print("you got a B")
    elif mark>=35:
        print("you got a C")
    else:
        print("you got a D")
