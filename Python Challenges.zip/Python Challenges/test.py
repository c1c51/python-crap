import random
y=random.randint(0,4)
print(y)
