n=input("name?")
print("whats you favoutrite subject ",n,"?")
s=input()
print("I like ",s," as well")
