w=int(input("width?"))
l=int(input("length?"))
r=int(input("radius?"))
print((w*l)-((r*r)*3.14159265358979323846264338))
