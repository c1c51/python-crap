o=input("name an olympic value")
o=o.lower()
if o=="respect" or o=="excellence" or o=="friendship":
    print("thats correct")
else:
    print("try again")
    
