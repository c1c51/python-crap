s=input("TYPE A SENTENCE")
s=s.upper()
print(s)
