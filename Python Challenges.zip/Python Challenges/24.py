while True:
     print("spaces")
     spaces=int(input())
     print("x")
     x1="x"
     spaces1=" "
     x=int(input())
     print("spaces:",spaces,",X's:",x)
     while x>0 or spaces>0:
          if x>0:
             print(x1)
             x=x-1
          if spaces>0:
             print(spaces1)
             spaces=spaces-1
          
             
          

    



