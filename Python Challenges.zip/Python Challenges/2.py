x=int(input("whats the first number?"))
y=int(input("whats the second number?"))
print((x+y)/2)
