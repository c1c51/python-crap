tv=int(input("how much tv do you watch"))
if tv<2:
    print("that shouldnt rot your brain too much")
elif tv<4:
    print("Aren't you getting square eyes?")
else:
    print("Fresh air beats channel flicking")
