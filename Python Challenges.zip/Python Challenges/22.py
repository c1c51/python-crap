d=int(input("whats the distance(in meters)"))
t=int(input("how long did it take you(in seconds)"))
print("Your average speed was ",d/t,"m/s")
      
