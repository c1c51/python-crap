y=1
while y<=10:
    print(y)
    y=y+1
