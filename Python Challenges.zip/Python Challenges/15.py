sent=input("sentence")
sent=sent.lower()
print(sent)
