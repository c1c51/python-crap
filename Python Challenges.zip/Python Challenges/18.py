y=int(input("number?"))
x=1
while x<13:
    print(x*y)
    x=x+1
    
      
