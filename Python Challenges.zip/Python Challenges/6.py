n=input("name")
n=n.lower()
if n=="adam":
    print("You're Cool")
else:
    print("Nice to meet you")
