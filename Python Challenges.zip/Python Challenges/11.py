s=input("TYPE A SENTENCE")
print(len(s))
