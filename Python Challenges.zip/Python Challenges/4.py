x=int(input("first number?"))
y=int(input("second number?"))
print(x/y)
